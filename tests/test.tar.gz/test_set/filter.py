#!/usr/bin/env python
# -*- coding: utf-8 -*-

qrel_ids = {} 

with open("./qrels_sorted.train.tsv") as qrels:
    for line in qrels:
        qid, _, _, _ = line.split('\t')

        qrel_ids[int(qid)] = None


queries = {} 

with open("./queries.tsv") as qrels:
    with open("queries_filtered.tsv", "w+") as writer:
        for line in qrels:
            qid, _ = line.split("\t")

            if int(qid) in qrel_ids:
                writer.write(line)

